test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(set_c, set)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(set_c) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set_c == {8, 14}\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
