test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(my_info_long, dict)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> my_info == my_info_long\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> my_info_long is not my_info\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
